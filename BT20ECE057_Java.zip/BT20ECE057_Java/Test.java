  /**
  explicit import                       implicit import 

  import java.util.Al                   import java.util.*
  
  we should prefer explicit import 
  pacage:  it is an encapsulation mechanism to group 
  related clasees and interfaces into a single unit.
  package com.durgasoft.ocja;
  universally accepted naming convenction : com.icicbank;{in reverse way
  public com.durgasoft;
  public class test
  {
    public static void(String[] args)
    {
      system.out.print.ln("package Demo ");
    }
  }

  javac -d .test.java  ->  to place in the destination diretory
   

   */

   public class Test
   {
    public static void main(String[] args)
    {
        
    }
   }