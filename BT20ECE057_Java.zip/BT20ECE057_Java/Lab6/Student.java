public class Student {
    String Name;
    String Enrollment_Number;
    String Branch;
    int Year;
    int Semester;
    
    public Student(String Name, String Enrollment_Number, String Branch, int Year, int Semester){
        this.Name = Name;
        this.Enrollment_Number = Enrollment_Number;
        this.Branch = Branch;
        this.Year = Year;
        this.Semester = Semester;
    }
}