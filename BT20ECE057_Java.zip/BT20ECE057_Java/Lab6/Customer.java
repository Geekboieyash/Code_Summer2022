public class Customer {
    String Customer_name;
    String Customer_Add;
    String Customer_Number;
    int Pincode;
    
    public Customer(String Customer_name,
    String Customer_Add,
    String Customer_Number,
    int Pincode){
         this.Customer_name = Customer_name;
         this.Customer_Add = Customer_Add;
         this.Customer_Number = Customer_Number;
         this.Pincode = Pincode;
     }
   
}