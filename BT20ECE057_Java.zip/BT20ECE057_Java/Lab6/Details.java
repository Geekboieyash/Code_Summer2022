public class Details {

    String Name;
    String Mobile_Number;
    String Address;
    Double Age;

    public Details(String Name,String Mobile_Number, String Address, Double Age){
        this.Name = Name;
        this.Mobile_Number = Mobile_Number;
        this.Address = Address;
        this.Age = Age;       
    }
}
