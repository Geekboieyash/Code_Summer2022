class Call
{
  public static void main(String args[])
  {
    System.out.println("Call Me");
     PickUpCall p1=new  PickUpCall();
     p1.show();
 }
}

class PickUpCall
{
  public void show()
  {
   System.out.println(" I PickUp TheCall ");
  }
}