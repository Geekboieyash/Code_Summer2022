// A program that uses simple Point class and na ve initialization of its data. 

class Point {
	int x;
	int y;
	}

// This class declares an object of type Point.
class Demonstration_34{
	public static void main(String args[]) {
	Point mypoint = new Point();

	// assign values to mypoint's instance variables
	mypoint.x = 10;
	mypoint.y = 20;

	// access the values from mypoint s instance variable
	System.out.println("x " + mypoint.x);
	System.out.println("x " + mypoint.y);

	}
}