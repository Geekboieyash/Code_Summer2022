public class staticDemo {
    static int a = 10;
    static void display()
    {
        System.out.println("Static class");

    }
    public static void main(String args[])
    {
        System.out.println(a);
        display();
    }
}
